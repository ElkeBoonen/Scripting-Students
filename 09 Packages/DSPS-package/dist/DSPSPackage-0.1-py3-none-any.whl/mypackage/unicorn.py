from playsound import playsound 

def play():
    """ Play sound
    Parameters
        None
    Return
        None
    """
    playsound("unicorn.mp3")
