def sum(a, b):
    """ Maakt de som
    Parameters:
        2 getallen
    Returns:
        som van de twee getallen
    """
    return a+b

def product(a,b):
    """ Maakt het product
    Parameters:
        2 getallen
    Returns:
        product van de twee getallen
    """
    return a*b

def modulo(a,b):
    return a % b