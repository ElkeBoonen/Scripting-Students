def helloworld():
    print("Hello world")

def reverse(value):
    print(value[:-1])